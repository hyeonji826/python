# shapes/__init__.py
# from shapes import circle, rectangle
# from shapes import * 

# *을 사용해도 __all__에 포함된 모듈만 import 가능함
__all__ = ["circle", "rectangle"]

