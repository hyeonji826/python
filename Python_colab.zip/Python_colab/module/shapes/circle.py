PI = 3.141592653589793

def area(radius):
    return PI * radius * radius

def circumference(radius):
    return 2 * PI * radius