def area(width, height):
    return width * height

def perimeter(width, height):
    return 2 * (width + height)